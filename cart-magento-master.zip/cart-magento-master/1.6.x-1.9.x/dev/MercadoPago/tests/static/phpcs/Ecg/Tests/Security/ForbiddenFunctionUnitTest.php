<?php

class Ecg_Tests_Security_ForbiddenFunctionUnitTest extends AbstractSniffUnitTest
{
    public function getErrorList()
    {
        return array();

    }

    public function getWarningList()
    {
        return array();
    }
}
